#ifndef NAME_GEN
#define NAME_GEN

//generates the name of a city
//type of the world 1=elf 2=medieval 3=futurist
char* name_gen(int type,int* len);

#endif