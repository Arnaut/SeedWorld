#ifndef CITY_GEN
#define CITY_GEN

//build the city
SDL_Surface* build_city(int* w_map, SDL_Surface* img,int w_rows,int w_cols,int type);

#endif
